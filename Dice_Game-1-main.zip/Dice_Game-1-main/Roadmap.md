- [x] Establish game rules
- [x] Structure user experience goal
- [x] research existing code
- [x] Create Read.me
- [x] Clone and upload code
- [x] Make changes to code
- [ ] Test and finalize
- [ ] Work on presentation







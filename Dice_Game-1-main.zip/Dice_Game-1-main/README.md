# Dice_Game
Dice game simulator.
This is a game of dice with one or more players where a random number for a dice roll is generated. The game will be able to be played by anyone. The game will be able to go back and forth between multiple users so that multiple people can play at the same time.
